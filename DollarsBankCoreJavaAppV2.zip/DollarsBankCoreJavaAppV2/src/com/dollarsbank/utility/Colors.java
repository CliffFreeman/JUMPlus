package com.dollarsbank.utility;

public class Colors {
	
	public final String BLACK = "\u001b[30m";
	public final String RED = "\u001b[31m";
	public final String GREEN = "\u001b[32m";
	public final String YELLOW = "\u001b[33m";
	public final String BLUE = "\u001b[34m";
	public final String MAGENTA = "\u001b[35m";
	public final String CYAN = "\u001b[36m";
	public final String RESET = "\u001b[0m";
}
